﻿namespace ScitaAvccSDK_Test_CSharp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.labe = new System.Windows.Forms.Label();
            this.label_Available = new System.Windows.Forms.Label();
            this.label_Total_Storage_Space = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label_AxleDistance = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label_Speed = new System.Windows.Forms.Label();
            this.label_AxleInfo = new System.Windows.Forms.Label();
            this.label_LicensePlate = new System.Windows.Forms.Label();
            this.picture_Vehicle_Image = new System.Windows.Forms.PictureBox();
            this.label_Direction = new System.Windows.Forms.Label();
            this.label_Class_Enabled = new System.Windows.Forms.Label();
            this.label_VehicleLength = new System.Windows.Forms.Label();
            this.label_Time_Stamp = new System.Windows.Forms.Label();
            this.label_VehicleWidth = new System.Windows.Forms.Label();
            this.label_Vehicle_Height = new System.Windows.Forms.Label();
            this.label_Axle_Count = new System.Windows.Forms.Label();
            this.label1_Class_Name = new System.Windows.Forms.Label();
            this.label_Class_Type = new System.Windows.Forms.Label();
            this.label_Sequence_No = new System.Windows.Forms.Label();
            this.label_Available_Free_Space = new System.Windows.Forms.Label();
            this.label_System_Up_Time = new System.Windows.Forms.Label();
            this.label_System_Up = new System.Windows.Forms.Label();
            this.label_Loop_Status = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label_Current_Frame_Rate = new System.Windows.Forms.Label();
            this.label_ = new System.Windows.Forms.Label();
            this.label_Required_frame_Rate = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label_Device_Error_Count = new System.Windows.Forms.Label();
            this.lable9 = new System.Windows.Forms.Label();
            this.lbl = new System.Windows.Forms.Label();
            this.label1_Processor_Temperature = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label_Ambient_Temperature = new System.Windows.Forms.Label();
            this.label_Firmware_Version = new System.Windows.Forms.Label();
            this.lable_Last_Update = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_Ipaddress = new System.Windows.Forms.TextBox();
            this.buttonDisconnect = new System.Windows.Forms.Button();
            this.button_Connect = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbl_Port = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.lbl_Status = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label_Approximate_Storage_Capacity = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label_Sensor_Status = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label_License_Status = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox_ResponceData = new System.Windows.Forms.TextBox();
            this.lable_Error_Status = new System.Windows.Forms.TextBox();
            this.label_resultInfo = new System.Windows.Forms.Label();
            this.checkBox_ImageRequried = new System.Windows.Forms.CheckBox();
            this.comboBox_DownloadType = new System.Windows.Forms.ComboBox();
            this.Nearesttime = new System.Windows.Forms.Label();
            this.textBox_nearest = new System.Windows.Forms.TextBox();
            this.button_DownloadTransactions = new System.Windows.Forms.Button();
            this.textBox_to = new System.Windows.Forms.TextBox();
            this.tolable = new System.Windows.Forms.Label();
            this.fromlable = new System.Windows.Forms.Label();
            this.textBox_From = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label_laneName = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picture_Vehicle_Image)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // labe
            // 
            this.labe.AutoSize = true;
            this.labe.Location = new System.Drawing.Point(17, 86);
            this.labe.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labe.Name = "labe";
            this.labe.Size = new System.Drawing.Size(172, 14);
            this.labe.TabIndex = 6;
            this.labe.Text = "Approx Storage Capacity :";
            // 
            // label_Available
            // 
            this.label_Available.AutoSize = true;
            this.label_Available.Location = new System.Drawing.Point(43, 62);
            this.label_Available.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Available.Name = "label_Available";
            this.label_Available.Size = new System.Drawing.Size(146, 14);
            this.label_Available.TabIndex = 4;
            this.label_Available.Text = "Available Free Space :";
            // 
            // label_Total_Storage_Space
            // 
            this.label_Total_Storage_Space.AutoSize = true;
            this.label_Total_Storage_Space.Location = new System.Drawing.Point(211, 38);
            this.label_Total_Storage_Space.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Total_Storage_Space.Name = "label_Total_Storage_Space";
            this.label_Total_Storage_Space.Size = new System.Drawing.Size(17, 14);
            this.label_Total_Storage_Space.TabIndex = 3;
            this.label_Total_Storage_Space.Text = "--";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(47, 38);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(142, 14);
            this.label6.TabIndex = 2;
            this.label6.Text = "Total Storage Space :";
            // 
            // groupBox7
            // 
            this.groupBox7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox7.Controls.Add(this.label23);
            this.groupBox7.Controls.Add(this.label21);
            this.groupBox7.Controls.Add(this.label14);
            this.groupBox7.Controls.Add(this.label19);
            this.groupBox7.Controls.Add(this.label27);
            this.groupBox7.Controls.Add(this.label28);
            this.groupBox7.Controls.Add(this.label26);
            this.groupBox7.Controls.Add(this.label24);
            this.groupBox7.Controls.Add(this.label25);
            this.groupBox7.Controls.Add(this.label22);
            this.groupBox7.Controls.Add(this.label16);
            this.groupBox7.Controls.Add(this.label12);
            this.groupBox7.Controls.Add(this.label13);
            this.groupBox7.Controls.Add(this.label11);
            this.groupBox7.Controls.Add(this.label_AxleDistance);
            this.groupBox7.Controls.Add(this.label_laneName);
            this.groupBox7.Controls.Add(this.label10);
            this.groupBox7.Controls.Add(this.label_Speed);
            this.groupBox7.Controls.Add(this.label_AxleInfo);
            this.groupBox7.Controls.Add(this.label_LicensePlate);
            this.groupBox7.Controls.Add(this.picture_Vehicle_Image);
            this.groupBox7.Controls.Add(this.label_Direction);
            this.groupBox7.Controls.Add(this.label_Class_Enabled);
            this.groupBox7.Controls.Add(this.label_VehicleLength);
            this.groupBox7.Controls.Add(this.label_Time_Stamp);
            this.groupBox7.Controls.Add(this.label_VehicleWidth);
            this.groupBox7.Controls.Add(this.label_Vehicle_Height);
            this.groupBox7.Controls.Add(this.label_Axle_Count);
            this.groupBox7.Controls.Add(this.label1_Class_Name);
            this.groupBox7.Controls.Add(this.label_Class_Type);
            this.groupBox7.Controls.Add(this.label_Sequence_No);
            this.groupBox7.Location = new System.Drawing.Point(16, 343);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox7.Size = new System.Drawing.Size(885, 388);
            this.groupBox7.TabIndex = 14;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Last Transaction";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(501, 191);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(100, 14);
            this.label23.TabIndex = 14;
            this.label23.Text = "Axle Distance :";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(530, 168);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(71, 14);
            this.label21.TabIndex = 14;
            this.label21.Text = "Axle Info :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(496, 143);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(105, 14);
            this.label14.TabIndex = 14;
            this.label14.Text = "Class Enabled :";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(512, 119);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(89, 14);
            this.label19.TabIndex = 12;
            this.label19.Text = "Time Stamp :";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(500, 325);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(100, 14);
            this.label28.TabIndex = 10;
            this.label28.Text = "Speed(kmph) :";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(501, 302);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(99, 14);
            this.label26.TabIndex = 10;
            this.label26.Text = "License Plate :";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(482, 283);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(118, 14);
            this.label24.TabIndex = 10;
            this.label24.Text = "Vehicle Direction :";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(493, 262);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(107, 14);
            this.label25.TabIndex = 10;
            this.label25.Text = "Vehicle Length :";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(500, 238);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(100, 14);
            this.label22.TabIndex = 10;
            this.label22.Text = "Vehicle Width :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(496, 215);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(104, 14);
            this.label16.TabIndex = 10;
            this.label16.Text = "Vehicle Height :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(517, 95);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(84, 14);
            this.label12.TabIndex = 8;
            this.label12.Text = "Axle Count :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(511, 71);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(90, 14);
            this.label13.TabIndex = 6;
            this.label13.Text = "Class Name :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(517, 47);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(83, 14);
            this.label11.TabIndex = 4;
            this.label11.Text = "Class Type :";
            // 
            // label_AxleDistance
            // 
            this.label_AxleDistance.AutoSize = true;
            this.label_AxleDistance.Location = new System.Drawing.Point(610, 191);
            this.label_AxleDistance.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_AxleDistance.Name = "label_AxleDistance";
            this.label_AxleDistance.Size = new System.Drawing.Size(17, 14);
            this.label_AxleDistance.TabIndex = 15;
            this.label_AxleDistance.Text = "--";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(502, 26);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(99, 14);
            this.label10.TabIndex = 2;
            this.label10.Text = "Sequence No :";
            // 
            // label_Speed
            // 
            this.label_Speed.AutoSize = true;
            this.label_Speed.Location = new System.Drawing.Point(610, 325);
            this.label_Speed.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Speed.Name = "label_Speed";
            this.label_Speed.Size = new System.Drawing.Size(17, 14);
            this.label_Speed.TabIndex = 11;
            this.label_Speed.Text = "--";
            // 
            // label_AxleInfo
            // 
            this.label_AxleInfo.AutoSize = true;
            this.label_AxleInfo.Location = new System.Drawing.Point(610, 168);
            this.label_AxleInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_AxleInfo.Name = "label_AxleInfo";
            this.label_AxleInfo.Size = new System.Drawing.Size(17, 14);
            this.label_AxleInfo.TabIndex = 15;
            this.label_AxleInfo.Text = "--";
            // 
            // label_LicensePlate
            // 
            this.label_LicensePlate.AutoSize = true;
            this.label_LicensePlate.Location = new System.Drawing.Point(610, 302);
            this.label_LicensePlate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_LicensePlate.Name = "label_LicensePlate";
            this.label_LicensePlate.Size = new System.Drawing.Size(17, 14);
            this.label_LicensePlate.TabIndex = 11;
            this.label_LicensePlate.Text = "--";
            // 
            // picture_Vehicle_Image
            // 
            this.picture_Vehicle_Image.Location = new System.Drawing.Point(12, 33);
            this.picture_Vehicle_Image.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.picture_Vehicle_Image.Name = "picture_Vehicle_Image";
            this.picture_Vehicle_Image.Size = new System.Drawing.Size(457, 326);
            this.picture_Vehicle_Image.TabIndex = 0;
            this.picture_Vehicle_Image.TabStop = false;
            // 
            // label_Direction
            // 
            this.label_Direction.AutoSize = true;
            this.label_Direction.Location = new System.Drawing.Point(610, 283);
            this.label_Direction.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Direction.Name = "label_Direction";
            this.label_Direction.Size = new System.Drawing.Size(17, 14);
            this.label_Direction.TabIndex = 11;
            this.label_Direction.Text = "--";
            // 
            // label_Class_Enabled
            // 
            this.label_Class_Enabled.AutoSize = true;
            this.label_Class_Enabled.Location = new System.Drawing.Point(610, 143);
            this.label_Class_Enabled.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Class_Enabled.Name = "label_Class_Enabled";
            this.label_Class_Enabled.Size = new System.Drawing.Size(17, 14);
            this.label_Class_Enabled.TabIndex = 15;
            this.label_Class_Enabled.Text = "--";
            // 
            // label_VehicleLength
            // 
            this.label_VehicleLength.AutoSize = true;
            this.label_VehicleLength.Location = new System.Drawing.Point(610, 262);
            this.label_VehicleLength.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_VehicleLength.Name = "label_VehicleLength";
            this.label_VehicleLength.Size = new System.Drawing.Size(17, 14);
            this.label_VehicleLength.TabIndex = 11;
            this.label_VehicleLength.Text = "--";
            // 
            // label_Time_Stamp
            // 
            this.label_Time_Stamp.AutoSize = true;
            this.label_Time_Stamp.Location = new System.Drawing.Point(610, 119);
            this.label_Time_Stamp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Time_Stamp.Name = "label_Time_Stamp";
            this.label_Time_Stamp.Size = new System.Drawing.Size(17, 14);
            this.label_Time_Stamp.TabIndex = 13;
            this.label_Time_Stamp.Text = "--";
            // 
            // label_VehicleWidth
            // 
            this.label_VehicleWidth.AutoSize = true;
            this.label_VehicleWidth.Location = new System.Drawing.Point(610, 238);
            this.label_VehicleWidth.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_VehicleWidth.Name = "label_VehicleWidth";
            this.label_VehicleWidth.Size = new System.Drawing.Size(17, 14);
            this.label_VehicleWidth.TabIndex = 11;
            this.label_VehicleWidth.Text = "--";
            // 
            // label_Vehicle_Height
            // 
            this.label_Vehicle_Height.AutoSize = true;
            this.label_Vehicle_Height.Location = new System.Drawing.Point(610, 215);
            this.label_Vehicle_Height.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Vehicle_Height.Name = "label_Vehicle_Height";
            this.label_Vehicle_Height.Size = new System.Drawing.Size(17, 14);
            this.label_Vehicle_Height.TabIndex = 11;
            this.label_Vehicle_Height.Text = "--";
            // 
            // label_Axle_Count
            // 
            this.label_Axle_Count.AutoSize = true;
            this.label_Axle_Count.Location = new System.Drawing.Point(610, 95);
            this.label_Axle_Count.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Axle_Count.Name = "label_Axle_Count";
            this.label_Axle_Count.Size = new System.Drawing.Size(17, 14);
            this.label_Axle_Count.TabIndex = 9;
            this.label_Axle_Count.Text = "--";
            // 
            // label1_Class_Name
            // 
            this.label1_Class_Name.AutoSize = true;
            this.label1_Class_Name.Location = new System.Drawing.Point(610, 71);
            this.label1_Class_Name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1_Class_Name.Name = "label1_Class_Name";
            this.label1_Class_Name.Size = new System.Drawing.Size(17, 14);
            this.label1_Class_Name.TabIndex = 7;
            this.label1_Class_Name.Text = "--";
            // 
            // label_Class_Type
            // 
            this.label_Class_Type.AutoSize = true;
            this.label_Class_Type.Location = new System.Drawing.Point(610, 47);
            this.label_Class_Type.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Class_Type.Name = "label_Class_Type";
            this.label_Class_Type.Size = new System.Drawing.Size(17, 14);
            this.label_Class_Type.TabIndex = 5;
            this.label_Class_Type.Text = "--";
            // 
            // label_Sequence_No
            // 
            this.label_Sequence_No.AutoSize = true;
            this.label_Sequence_No.Location = new System.Drawing.Point(610, 26);
            this.label_Sequence_No.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Sequence_No.Name = "label_Sequence_No";
            this.label_Sequence_No.Size = new System.Drawing.Size(17, 14);
            this.label_Sequence_No.TabIndex = 3;
            this.label_Sequence_No.Text = "--";
            // 
            // label_Available_Free_Space
            // 
            this.label_Available_Free_Space.AutoSize = true;
            this.label_Available_Free_Space.Location = new System.Drawing.Point(211, 62);
            this.label_Available_Free_Space.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Available_Free_Space.Name = "label_Available_Free_Space";
            this.label_Available_Free_Space.Size = new System.Drawing.Size(17, 14);
            this.label_Available_Free_Space.TabIndex = 5;
            this.label_Available_Free_Space.Text = "--";
            // 
            // label_System_Up_Time
            // 
            this.label_System_Up_Time.AutoSize = true;
            this.label_System_Up_Time.Location = new System.Drawing.Point(206, 219);
            this.label_System_Up_Time.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_System_Up_Time.Name = "label_System_Up_Time";
            this.label_System_Up_Time.Size = new System.Drawing.Size(17, 14);
            this.label_System_Up_Time.TabIndex = 31;
            this.label_System_Up_Time.Text = "--";
            // 
            // label_System_Up
            // 
            this.label_System_Up.AutoSize = true;
            this.label_System_Up.Font = new System.Drawing.Font("Verdana", 8.150944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_System_Up.Location = new System.Drawing.Point(75, 219);
            this.label_System_Up.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_System_Up.Name = "label_System_Up";
            this.label_System_Up.Size = new System.Drawing.Size(106, 13);
            this.label_System_Up.TabIndex = 30;
            this.label_System_Up.Text = "System UpTime :";
            // 
            // label_Loop_Status
            // 
            this.label_Loop_Status.AutoSize = true;
            this.label_Loop_Status.Location = new System.Drawing.Point(206, 195);
            this.label_Loop_Status.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Loop_Status.Name = "label_Loop_Status";
            this.label_Loop_Status.Size = new System.Drawing.Size(17, 14);
            this.label_Loop_Status.TabIndex = 29;
            this.label_Loop_Status.Text = "--";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 8.150944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(97, 195);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(83, 13);
            this.label9.TabIndex = 28;
            this.label9.Text = "Loop Status :";
            // 
            // label_Current_Frame_Rate
            // 
            this.label_Current_Frame_Rate.AutoSize = true;
            this.label_Current_Frame_Rate.Location = new System.Drawing.Point(206, 171);
            this.label_Current_Frame_Rate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Current_Frame_Rate.Name = "label_Current_Frame_Rate";
            this.label_Current_Frame_Rate.Size = new System.Drawing.Size(17, 14);
            this.label_Current_Frame_Rate.TabIndex = 27;
            this.label_Current_Frame_Rate.Text = "--";
            // 
            // label_
            // 
            this.label_.AutoSize = true;
            this.label_.Font = new System.Drawing.Font("Verdana", 8.150944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_.Location = new System.Drawing.Point(51, 171);
            this.label_.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_.Name = "label_";
            this.label_.Size = new System.Drawing.Size(128, 13);
            this.label_.TabIndex = 26;
            this.label_.Text = "Current frame Rate :";
            // 
            // label_Required_frame_Rate
            // 
            this.label_Required_frame_Rate.AutoSize = true;
            this.label_Required_frame_Rate.Location = new System.Drawing.Point(206, 147);
            this.label_Required_frame_Rate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Required_frame_Rate.Name = "label_Required_frame_Rate";
            this.label_Required_frame_Rate.Size = new System.Drawing.Size(17, 14);
            this.label_Required_frame_Rate.TabIndex = 25;
            this.label_Required_frame_Rate.Text = "--";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Verdana", 8.150944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(44, 147);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(135, 13);
            this.label17.TabIndex = 24;
            this.label17.Text = "Required frame Rate :";
            // 
            // label_Device_Error_Count
            // 
            this.label_Device_Error_Count.AutoSize = true;
            this.label_Device_Error_Count.Location = new System.Drawing.Point(206, 123);
            this.label_Device_Error_Count.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Device_Error_Count.Name = "label_Device_Error_Count";
            this.label_Device_Error_Count.Size = new System.Drawing.Size(17, 14);
            this.label_Device_Error_Count.TabIndex = 23;
            this.label_Device_Error_Count.Text = "--";
            // 
            // lable9
            // 
            this.lable9.AutoSize = true;
            this.lable9.Font = new System.Drawing.Font("Verdana", 8.150944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lable9.Location = new System.Drawing.Point(53, 123);
            this.lable9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lable9.Name = "lable9";
            this.lable9.Size = new System.Drawing.Size(126, 13);
            this.lable9.TabIndex = 22;
            this.lable9.Text = "Device Error Count :";
            // 
            // lbl
            // 
            this.lbl.AutoSize = true;
            this.lbl.Font = new System.Drawing.Font("Verdana", 8.150944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl.Location = new System.Drawing.Point(35, 99);
            this.lbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(140, 13);
            this.lbl.TabIndex = 20;
            this.lbl.Text = "Ambient Temperature :";
            // 
            // label1_Processor_Temperature
            // 
            this.label1_Processor_Temperature.AutoSize = true;
            this.label1_Processor_Temperature.Location = new System.Drawing.Point(206, 75);
            this.label1_Processor_Temperature.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1_Processor_Temperature.Name = "label1_Processor_Temperature";
            this.label1_Processor_Temperature.Size = new System.Drawing.Size(17, 14);
            this.label1_Processor_Temperature.TabIndex = 19;
            this.label1_Processor_Temperature.Text = "--";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Verdana", 8.150944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(24, 75);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(149, 13);
            this.label15.TabIndex = 18;
            this.label15.Text = "Processor Temperature :\t";
            // 
            // label_Ambient_Temperature
            // 
            this.label_Ambient_Temperature.AutoSize = true;
            this.label_Ambient_Temperature.Location = new System.Drawing.Point(206, 99);
            this.label_Ambient_Temperature.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Ambient_Temperature.Name = "label_Ambient_Temperature";
            this.label_Ambient_Temperature.Size = new System.Drawing.Size(17, 14);
            this.label_Ambient_Temperature.TabIndex = 21;
            this.label_Ambient_Temperature.Text = "--";
            // 
            // label_Firmware_Version
            // 
            this.label_Firmware_Version.AutoSize = true;
            this.label_Firmware_Version.Location = new System.Drawing.Point(206, 51);
            this.label_Firmware_Version.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Firmware_Version.Name = "label_Firmware_Version";
            this.label_Firmware_Version.Size = new System.Drawing.Size(17, 14);
            this.label_Firmware_Version.TabIndex = 3;
            this.label_Firmware_Version.Text = "--";
            // 
            // lable_Last_Update
            // 
            this.lable_Last_Update.AutoSize = true;
            this.lable_Last_Update.ForeColor = System.Drawing.Color.Black;
            this.lable_Last_Update.Location = new System.Drawing.Point(132, 50);
            this.lable_Last_Update.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lable_Last_Update.Name = "lable_Last_Update";
            this.lable_Last_Update.Size = new System.Drawing.Size(32, 14);
            this.lable_Last_Update.TabIndex = 4;
            this.lable_Last_Update.Text = "-----";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 8.150944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 24);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Host address :";
            // 
            // lbl_Ipaddress
            // 
            this.lbl_Ipaddress.Location = new System.Drawing.Point(104, 19);
            this.lbl_Ipaddress.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lbl_Ipaddress.Name = "lbl_Ipaddress";
            this.lbl_Ipaddress.Size = new System.Drawing.Size(151, 22);
            this.lbl_Ipaddress.TabIndex = 1;
            this.lbl_Ipaddress.Text = "192.168.2.181";
            // 
            // buttonDisconnect
            // 
            this.buttonDisconnect.Location = new System.Drawing.Point(263, 44);
            this.buttonDisconnect.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonDisconnect.Name = "buttonDisconnect";
            this.buttonDisconnect.Size = new System.Drawing.Size(117, 27);
            this.buttonDisconnect.TabIndex = 3;
            this.buttonDisconnect.Text = "Disconnect";
            this.buttonDisconnect.UseVisualStyleBackColor = true;
            this.buttonDisconnect.Visible = false;
            this.buttonDisconnect.Click += new System.EventHandler(this.buttonDisconnect_Click);
            // 
            // button_Connect
            // 
            this.button_Connect.Location = new System.Drawing.Point(263, 17);
            this.button_Connect.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_Connect.Name = "button_Connect";
            this.button_Connect.Size = new System.Drawing.Size(117, 27);
            this.button_Connect.TabIndex = 2;
            this.button_Connect.Text = "&Connect";
            this.button_Connect.UseVisualStyleBackColor = true;
            this.button_Connect.Click += new System.EventHandler(this.button_Connect_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbl_Port);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.lbl_Ipaddress);
            this.groupBox1.Controls.Add(this.buttonDisconnect);
            this.groupBox1.Controls.Add(this.button_Connect);
            this.groupBox1.Location = new System.Drawing.Point(16, 15);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(469, 82);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Connection";
            // 
            // lbl_Port
            // 
            this.lbl_Port.Location = new System.Drawing.Point(104, 46);
            this.lbl_Port.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lbl_Port.Name = "lbl_Port";
            this.lbl_Port.Size = new System.Drawing.Size(151, 22);
            this.lbl_Port.TabIndex = 5;
            this.lbl_Port.Text = "8080";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 8.150944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(59, 51);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "port :";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lable_Last_Update);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.lbl_Status);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(493, 15);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Size = new System.Drawing.Size(327, 82);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Status";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(14, 50);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(101, 14);
            this.label18.TabIndex = 3;
            this.label18.Text = "Last Updated :";
            // 
            // lbl_Status
            // 
            this.lbl_Status.AutoSize = true;
            this.lbl_Status.ForeColor = System.Drawing.Color.Black;
            this.lbl_Status.Location = new System.Drawing.Point(132, 23);
            this.lbl_Status.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Status.Name = "lbl_Status";
            this.lbl_Status.Size = new System.Drawing.Size(101, 14);
            this.lbl_Status.TabIndex = 2;
            this.lbl_Status.Text = "Not Connected";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(58, 23);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 14);
            this.label2.TabIndex = 0;
            this.label2.Text = "Service :";
            // 
            // label_Approximate_Storage_Capacity
            // 
            this.label_Approximate_Storage_Capacity.AutoSize = true;
            this.label_Approximate_Storage_Capacity.Location = new System.Drawing.Point(211, 86);
            this.label_Approximate_Storage_Capacity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Approximate_Storage_Capacity.Name = "label_Approximate_Storage_Capacity";
            this.label_Approximate_Storage_Capacity.Size = new System.Drawing.Size(17, 14);
            this.label_Approximate_Storage_Capacity.TabIndex = 7;
            this.label_Approximate_Storage_Capacity.Text = "--";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label_System_Up_Time);
            this.groupBox3.Controls.Add(this.label_System_Up);
            this.groupBox3.Controls.Add(this.label_Loop_Status);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label_Current_Frame_Rate);
            this.groupBox3.Controls.Add(this.label_);
            this.groupBox3.Controls.Add(this.label_Required_frame_Rate);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label_Device_Error_Count);
            this.groupBox3.Controls.Add(this.lable9);
            this.groupBox3.Controls.Add(this.label_Ambient_Temperature);
            this.groupBox3.Controls.Add(this.lbl);
            this.groupBox3.Controls.Add(this.label1_Processor_Temperature);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label_Firmware_Version);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label_Sensor_Status);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Location = new System.Drawing.Point(16, 101);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Size = new System.Drawing.Size(469, 243);
            this.groupBox3.TabIndex = 12;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Controller Information";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 8.150944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(65, 51);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 13);
            this.label7.TabIndex = 2;
            this.label7.Text = "Firmware Version :";
            // 
            // label_Sensor_Status
            // 
            this.label_Sensor_Status.AutoSize = true;
            this.label_Sensor_Status.Location = new System.Drawing.Point(206, 27);
            this.label_Sensor_Status.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Sensor_Status.Name = "label_Sensor_Status";
            this.label_Sensor_Status.Size = new System.Drawing.Size(17, 14);
            this.label_Sensor_Status.TabIndex = 1;
            this.label_Sensor_Status.Text = "--";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 8.150944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(83, 27);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Sensor Status :";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label_License_Status);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.label_Approximate_Storage_Capacity);
            this.groupBox5.Controls.Add(this.labe);
            this.groupBox5.Controls.Add(this.label_Available_Free_Space);
            this.groupBox5.Controls.Add(this.label_Available);
            this.groupBox5.Controls.Add(this.label_Total_Storage_Space);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Location = new System.Drawing.Point(493, 101);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox5.Size = new System.Drawing.Size(606, 243);
            this.groupBox5.TabIndex = 13;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Storage And License";
            // 
            // label_License_Status
            // 
            this.label_License_Status.AutoSize = true;
            this.label_License_Status.Location = new System.Drawing.Point(211, 110);
            this.label_License_Status.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_License_Status.Name = "label_License_Status";
            this.label_License_Status.Size = new System.Drawing.Size(17, 14);
            this.label_License_Status.TabIndex = 9;
            this.label_License_Status.Text = "--";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(81, 110);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 14);
            this.label8.TabIndex = 8;
            this.label8.Text = "License Status :";
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox4.Controls.Add(this.textBox_ResponceData);
            this.groupBox4.Controls.Add(this.lable_Error_Status);
            this.groupBox4.Controls.Add(this.label_resultInfo);
            this.groupBox4.Controls.Add(this.checkBox_ImageRequried);
            this.groupBox4.Controls.Add(this.comboBox_DownloadType);
            this.groupBox4.Controls.Add(this.Nearesttime);
            this.groupBox4.Controls.Add(this.textBox_nearest);
            this.groupBox4.Controls.Add(this.button_DownloadTransactions);
            this.groupBox4.Controls.Add(this.textBox_to);
            this.groupBox4.Controls.Add(this.tolable);
            this.groupBox4.Controls.Add(this.fromlable);
            this.groupBox4.Controls.Add(this.textBox_From);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Location = new System.Drawing.Point(909, 343);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox4.Size = new System.Drawing.Size(450, 388);
            this.groupBox4.TabIndex = 14;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Download Records";
            // 
            // textBox_ResponceData
            // 
            this.textBox_ResponceData.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox_ResponceData.Location = new System.Drawing.Point(13, 125);
            this.textBox_ResponceData.Multiline = true;
            this.textBox_ResponceData.Name = "textBox_ResponceData";
            this.textBox_ResponceData.Size = new System.Drawing.Size(422, 168);
            this.textBox_ResponceData.TabIndex = 15;
            // 
            // lable_Error_Status
            // 
            this.lable_Error_Status.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lable_Error_Status.Location = new System.Drawing.Point(13, 299);
            this.lable_Error_Status.Multiline = true;
            this.lable_Error_Status.Name = "lable_Error_Status";
            this.lable_Error_Status.ReadOnly = true;
            this.lable_Error_Status.Size = new System.Drawing.Size(422, 50);
            this.lable_Error_Status.TabIndex = 14;
            // 
            // label_resultInfo
            // 
            this.label_resultInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label_resultInfo.AutoSize = true;
            this.label_resultInfo.Location = new System.Drawing.Point(21, 366);
            this.label_resultInfo.Name = "label_resultInfo";
            this.label_resultInfo.Size = new System.Drawing.Size(217, 14);
            this.label_resultInfo.TabIndex = 10;
            this.label_resultInfo.Text = "Downloaded Transaction Count : ";
            // 
            // checkBox_ImageRequried
            // 
            this.checkBox_ImageRequried.AutoSize = true;
            this.checkBox_ImageRequried.Location = new System.Drawing.Point(24, 98);
            this.checkBox_ImageRequried.Name = "checkBox_ImageRequried";
            this.checkBox_ImageRequried.Size = new System.Drawing.Size(126, 18);
            this.checkBox_ImageRequried.TabIndex = 12;
            this.checkBox_ImageRequried.Text = "Image Requried";
            this.checkBox_ImageRequried.UseVisualStyleBackColor = true;
            // 
            // comboBox_DownloadType
            // 
            this.comboBox_DownloadType.FormattingEnabled = true;
            this.comboBox_DownloadType.Items.AddRange(new object[] {
            "Time",
            "Sequence No",
            "Statistics"});
            this.comboBox_DownloadType.Location = new System.Drawing.Point(69, 37);
            this.comboBox_DownloadType.Name = "comboBox_DownloadType";
            this.comboBox_DownloadType.Size = new System.Drawing.Size(153, 22);
            this.comboBox_DownloadType.TabIndex = 9;
            this.comboBox_DownloadType.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // Nearesttime
            // 
            this.Nearesttime.AutoSize = true;
            this.Nearesttime.Location = new System.Drawing.Point(279, 20);
            this.Nearesttime.Name = "Nearesttime";
            this.Nearesttime.Size = new System.Drawing.Size(99, 14);
            this.Nearesttime.TabIndex = 8;
            this.Nearesttime.Text = "Nearest Time :";
            this.Nearesttime.Visible = false;
            // 
            // textBox_nearest
            // 
            this.textBox_nearest.Location = new System.Drawing.Point(282, 37);
            this.textBox_nearest.Name = "textBox_nearest";
            this.textBox_nearest.Size = new System.Drawing.Size(153, 22);
            this.textBox_nearest.TabIndex = 7;
            this.textBox_nearest.Visible = false;
            // 
            // button_DownloadTransactions
            // 
            this.button_DownloadTransactions.Enabled = false;
            this.button_DownloadTransactions.Location = new System.Drawing.Point(346, 95);
            this.button_DownloadTransactions.Name = "button_DownloadTransactions";
            this.button_DownloadTransactions.Size = new System.Drawing.Size(89, 23);
            this.button_DownloadTransactions.TabIndex = 6;
            this.button_DownloadTransactions.Text = "D&ownload";
            this.button_DownloadTransactions.UseVisualStyleBackColor = true;
            this.button_DownloadTransactions.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox_to
            // 
            this.textBox_to.Location = new System.Drawing.Point(282, 65);
            this.textBox_to.Name = "textBox_to";
            this.textBox_to.Size = new System.Drawing.Size(153, 22);
            this.textBox_to.TabIndex = 5;
            // 
            // tolable
            // 
            this.tolable.AutoSize = true;
            this.tolable.Location = new System.Drawing.Point(245, 69);
            this.tolable.Name = "tolable";
            this.tolable.Size = new System.Drawing.Size(30, 14);
            this.tolable.TabIndex = 4;
            this.tolable.Text = "To :";
            // 
            // fromlable
            // 
            this.fromlable.AutoSize = true;
            this.fromlable.Location = new System.Drawing.Point(21, 69);
            this.fromlable.Name = "fromlable";
            this.fromlable.Size = new System.Drawing.Size(47, 14);
            this.fromlable.TabIndex = 3;
            this.fromlable.Text = "From :";
            // 
            // textBox_From
            // 
            this.textBox_From.Location = new System.Drawing.Point(69, 65);
            this.textBox_From.Name = "textBox_From";
            this.textBox_From.Size = new System.Drawing.Size(153, 22);
            this.textBox_From.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 41);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 14);
            this.label5.TabIndex = 0;
            this.label5.Text = "Type : ";
            // 
            // label_laneName
            // 
            this.label_laneName.AutoSize = true;
            this.label_laneName.Location = new System.Drawing.Point(610, 343);
            this.label_laneName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_laneName.Name = "label_laneName";
            this.label_laneName.Size = new System.Drawing.Size(17, 14);
            this.label_laneName.TabIndex = 11;
            this.label_laneName.Text = "--";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(553, 343);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(47, 14);
            this.label27.TabIndex = 10;
            this.label27.Text = "Lane :";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1366, 745);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox5);
            this.Font = new System.Drawing.Font("Verdana", 8.830189F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Scita Communicator AVCC Sample Applicaion";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picture_Vehicle_Image)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label labe;
        private System.Windows.Forms.Label label_Available;
        private System.Windows.Forms.Label label_Total_Storage_Space;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox picture_Vehicle_Image;
        private System.Windows.Forms.Label label_Class_Enabled;
        private System.Windows.Forms.Label label_Time_Stamp;
        private System.Windows.Forms.Label label_Vehicle_Height;
        private System.Windows.Forms.Label label_Axle_Count;
        private System.Windows.Forms.Label label1_Class_Name;
        private System.Windows.Forms.Label label_Class_Type;
        private System.Windows.Forms.Label label_Sequence_No;
        private System.Windows.Forms.Label label_Available_Free_Space;
        private System.Windows.Forms.Label label_System_Up_Time;
        private System.Windows.Forms.Label label_System_Up;
        private System.Windows.Forms.Label label_Loop_Status;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label_Current_Frame_Rate;
        private System.Windows.Forms.Label label_;
        private System.Windows.Forms.Label label_Required_frame_Rate;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label_Device_Error_Count;
        private System.Windows.Forms.Label lable9;
        private System.Windows.Forms.Label lbl;
        private System.Windows.Forms.Label label1_Processor_Temperature;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label_Ambient_Temperature;
        private System.Windows.Forms.Label label_Firmware_Version;
        private System.Windows.Forms.Label lable_Last_Update;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox lbl_Ipaddress;
        private System.Windows.Forms.Button buttonDisconnect;
        private System.Windows.Forms.Button button_Connect;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox lbl_Port;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lbl_Status;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label_Approximate_Storage_Capacity;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label_Sensor_Status;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label_License_Status;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button_DownloadTransactions;
        private System.Windows.Forms.TextBox textBox_to;
        private System.Windows.Forms.Label tolable;
        private System.Windows.Forms.Label fromlable;
        private System.Windows.Forms.TextBox textBox_From;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label Nearesttime;
        private System.Windows.Forms.TextBox textBox_nearest;
        private System.Windows.Forms.ComboBox comboBox_DownloadType;
        private System.Windows.Forms.Label label_resultInfo;
        private System.Windows.Forms.CheckBox checkBox_ImageRequried;
        private System.Windows.Forms.TextBox lable_Error_Status;
        private System.Windows.Forms.TextBox textBox_ResponceData;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label_AxleDistance;
        private System.Windows.Forms.Label label_AxleInfo;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label_VehicleLength;
        private System.Windows.Forms.Label label_VehicleWidth;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label_Direction;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label_Speed;
        private System.Windows.Forms.Label label_LicensePlate;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label_laneName;
    }
}

