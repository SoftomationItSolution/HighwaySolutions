﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;

using Scita.Managed;  // Must Add this namespace

using System.IO;

namespace ScitaAvccSDK_Test_CSharp
{

    public partial class Form1 : Form
    {

        ManagedScitaCommunicator m_Communicator = null; // Class of the Avcc Communicator Library

        public Form1()
        {
            InitializeComponent();

            comboBox_DownloadType.SelectedIndex = 0;

            textBox_ResponceData.ScrollBars = ScrollBars.Vertical;
        }

        private void button_Connect_Click(object sender, EventArgs e)
        {
            button_DownloadTransactions.Enabled = false;
            if (button_Connect.Text == "&Connect")
            {
                if (m_Communicator == null)
                {

                    m_Communicator = new ManagedScitaCommunicator();   // Instantiate the ScitaCommunicator object 

                    m_Communicator.OnNewTransactionEvent += UpdateAvccTranasctionDetails; //Add the function to Event  

                    m_Communicator.OnAvccStorageLicenseEvent += UpdateAvccStorageAndLicenceDetails; //Add the function to Event 

                    m_Communicator.OnAvccStatusEvent += UpdateAvccStatusDetails;  //Add the function to Event 

                    m_Communicator.OnConnectdEvent += OnConnect;  //Add the function to Event 

                    m_Communicator.OnDisConnectedEvent += OnDisConnect;  //Add the function to Event 

                    m_Communicator.OnHealthStatusEvent += m_Communicator_OnHealthStatusEvent;

                    m_Communicator.OnVehicleEntryEvent += m_Communicator_OnVehicleEntryEvent;
                    m_Communicator.OnVehicleExitEvent += m_Communicator_OnVehicleExitEvent;

                    m_Communicator.SetAutoConnected(true);   //Automatically reconnect once the client is disconnected 

                    try
                    {
                        String ipAddress = lbl_Ipaddress.Text.ToString();
                        int port = Convert.ToInt32(lbl_Port.Text);

                        if (m_Communicator.Open(ipAddress, port))
                        {
                            lbl_Status.Text = "Trying to Connect .";
                            m_Communicator.Connect();

                            m_Communicator.Start();

                            button_Connect.Text = "&DisConnect";

                            button_DownloadTransactions.Enabled = true;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString(), "Error");
                        button_Connect.Text = "&DisConnect";
                    }

                }
                else
                {
                    if (m_Communicator != null)
                    {
                        m_Communicator.DisConnect();

                        m_Communicator.Close();

                        m_Communicator.OnNewTransactionEvent -= UpdateAvccTranasctionDetails; //Add the function to Event  

                        m_Communicator.OnAvccStorageLicenseEvent -= UpdateAvccStorageAndLicenceDetails; //Add the function to Event 

                        m_Communicator.OnAvccStatusEvent -= UpdateAvccStatusDetails;  //Add the function to Event 

                        m_Communicator.OnConnectdEvent -= OnConnect;  //Add the function to Event 

                        m_Communicator.OnDisConnectedEvent -= OnDisConnect;  //Add the function to Event 

                        m_Communicator = null;
                    }
                }

                //button_Connect.Text = "&DisConnect";

            }
            else
            {
                if (m_Communicator != null)
                {
                    m_Communicator.Stop();
                    m_Communicator.DisConnect();

                    //lbl_Status.Text = "Connection Closed .";

                    m_Communicator.OnNewTransactionEvent -= UpdateAvccTranasctionDetails; //Add the function to Event  

                    m_Communicator.OnAvccStorageLicenseEvent -= UpdateAvccStorageAndLicenceDetails; //Add the function to Event 

                    m_Communicator.OnAvccStatusEvent -= UpdateAvccStatusDetails;  //Add the function to Event 

                    // m_Communicator.OnConnectdEvent -= OnConnect;  //Add the function to Event 

                    //m_Communicator.OnDisConnectedEvent -= OnDisConnect;  //Add the function to Event 

                    m_Communicator = null;

                }
                m_Communicator = null;
            }
            Application.DoEvents();
        }

        void m_Communicator_OnVehicleExitEvent()
        {
            if (InvokeRequired)
            {
                Invoke(new MethodInvoker(() =>
                {
                    m_Communicator_OnVehicleExitEvent();
                }));
                return; 
            }

            textBox_ResponceData.AppendText(String.Format("{1}{0} : Vehicle exit event", DateTime.Now.ToString("HH:mm:ss.fff"), Environment.NewLine));
        }

        void m_Communicator_OnVehicleEntryEvent()
        {
            if (InvokeRequired)
            {
                Invoke(new MethodInvoker(() =>
                {
                    m_Communicator_OnVehicleEntryEvent();
                }));
                return;
            }

            textBox_ResponceData.AppendText(String.Format("{1}{0} : Vehicle Entry event", DateTime.Now.ToString("HH:mm:ss.fff"), Environment.NewLine));
        }

        void m_Communicator_OnHealthStatusEvent(ManagedHealthStatus healthStatus)
        {
            Console.WriteLine("Timestamp of the health request :{0}", healthStatus.TimeStamp);
            Console.WriteLine("Is there an error in the system :{0}", healthStatus.IsError);

            int errorCount = healthStatus.FaultySensors == null ? 0 : healthStatus.FaultySensors.Length;
            Console.WriteLine("Total errror sensor count :{0}", errorCount);
        }

        void UpdateAvccTranasctionDetails(ManagedTransactionDetails transactionDetails)
        {
            try
            {
                if (InvokeRequired)
                {
                    Invoke(new MethodInvoker(() =>
                    {
                        UpdateAvccTranasctionDetails(transactionDetails);
                    }));
                    return;
                }

                if (!lable_Last_Update.InvokeRequired)
                {
                    lable_Last_Update.Text = System.DateTime.Now.ToString();
                } 

                label_Sequence_No.Text = Convert.ToString(transactionDetails.SequenceNo);
                label_Class_Type.Text = Convert.ToString(transactionDetails.ClassType);
                label1_Class_Name.Text = Convert.ToString(transactionDetails.ClassName);
                label_Axle_Count.Text = Convert.ToString(transactionDetails.AxleCount);
                label_Vehicle_Height.Text = Convert.ToString(transactionDetails.VehicleHeight);
                label_Time_Stamp.Text = Convert.ToString(transactionDetails.TimeStamp);
                label_Class_Enabled.Text = Convert.ToString(transactionDetails.ClassEnabled);
                label_LicensePlate.Text = Convert.ToString(transactionDetails.LicenseNumber);
                label_Speed.Text = Convert.ToString(transactionDetails.Speed) ;
                label_laneName.Text = transactionDetails.LaneName;

                string axleInfo = Convert.ToString(transactionDetails.AxleInfo.Length) + "=";

                for (int i = 0; i < transactionDetails.AxleInfo.Length; i++)
                {
                    axleInfo += transactionDetails.AxleInfo[i].ToString() + ",";
                }

                label_AxleInfo.Text = axleInfo;

                string axleDistance = Convert.ToString(transactionDetails.AxleDistance.Length) + "=";

                for (int i = 0; i < transactionDetails.AxleDistance.Length; i++)
                {
                    axleDistance += transactionDetails.AxleDistance[i].ToString() + ",";
                }

                label_AxleInfo.Text = axleInfo;
                label_AxleDistance.Text = axleDistance;

                label_VehicleWidth.Text = Convert.ToString(transactionDetails.VehicleWidth);
                label_VehicleLength.Text = Convert.ToString(transactionDetails.VehicleLength);
                label_Direction.Text = Convert.ToString(transactionDetails.VehicleDirection);

                if (picture_Vehicle_Image.Image != null)
                {
                    picture_Vehicle_Image.Image.Dispose();
                    picture_Vehicle_Image.Image = null;
                }

                picture_Vehicle_Image.Image = new Bitmap(transactionDetails.Image);
            }
            catch (Exception ex)
            {
                Console.WriteLine("{0}", ex.ToString());
            }
        }

        void UpdateAvccStorageAndLicenceDetails(ManagedStorageAndLicense storageAndLicenseDetails)
        {
            if (InvokeRequired)
            {
                Invoke(new MethodInvoker(() =>
                {
                    UpdateAvccStorageAndLicenceDetails(storageAndLicenseDetails);
                    return;
                }));
            }

            try
            {


                if (!lable_Last_Update.InvokeRequired)
                {
                    lable_Last_Update.Text = System.DateTime.Now.ToString();
                }

                label_Total_Storage_Space.Text = Convert.ToString(storageAndLicenseDetails.TotalStorageSpace);
                label_Available_Free_Space.Text = Convert.ToString(storageAndLicenseDetails.AvailableFreeSpace);
                label_Approximate_Storage_Capacity.Text = Convert.ToString(storageAndLicenseDetails.ApproximateStorageCapacity);
                label_License_Status.Text = Convert.ToString(storageAndLicenseDetails.LicenseStatus);
            }
            catch (Exception ex)
            {

            }
        }
         
        void UpdateAvccStatusDetails(ManagedStatusDetails statusDetails)
        {
            if (InvokeRequired)
            {
                Invoke(new MethodInvoker(() =>
                {
                    UpdateAvccStatusDetails(statusDetails);
                    return;
                }));
            }
            try
            {
                if(!lable_Last_Update.InvokeRequired)
                {
                    lable_Last_Update.Text = System.DateTime.Now.ToString();
                }

                label_Sensor_Status.Text = Convert.ToString(statusDetails.SensorStaus);
                label_Firmware_Version.Text = Convert.ToString(statusDetails.FirmwareVersion);
                label1_Processor_Temperature.Text = Convert.ToString(statusDetails.DeviceTemperature);
                label_Ambient_Temperature.Text = Convert.ToString(statusDetails.AtmosphereTemperature);
                label_Device_Error_Count.Text = Convert.ToString(statusDetails.DeviceErrorCount);
                label_Current_Frame_Rate.Text = Convert.ToString(statusDetails.CurrentFrameRate);
                label_Required_frame_Rate.Text = Convert.ToString(statusDetails.RequiredFrameRate);
                label_Loop_Status.Text = Convert.ToString(statusDetails.LoopStatus);
                label_System_Up_Time.Text = Convert.ToString(statusDetails.LastUpTime);
            }
            catch (Exception ex)
            {

            }
        }
        void OnConnect()
        {
            if (InvokeRequired)
            {
                Invoke(new MethodInvoker(() =>
                {
                    OnConnect();
                    return;
                }));
            }
            lbl_Status.Text = "Connected .";
            button_Connect.Text = "&DisConnect";


        }

        void OnDisConnect()
        {
            if (InvokeRequired)
            {
                Invoke(new MethodInvoker(() =>
                {
                    OnDisConnect();
                    return;
                }));
            }

            lbl_Status.Text = "Connection Closed .";
            button_Connect.Text = "&Connect";

        }
        private void buttonDisconnect_Click(object sender, EventArgs e)
        {

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (m_Communicator != null)
            {
                m_Communicator.DisConnect();

                m_Communicator.Close();

                m_Communicator = null;
            }
        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox_DownloadType.SelectedIndex == 0)
            {
                checkBox_ImageRequried.Visible = true;
                textBox_From.Visible = true;
                textBox_to.Visible = true;

                fromlable.Visible = true;
                tolable.Visible = true;

                fromlable.Text = "From";
                tolable.Text = "To";

                label_resultInfo.Text = "";

                textBox_nearest.Visible = false;
                Nearesttime.Visible = false;
                //24/06/2019 12:40:49
                //"dd/MM/yyyy HH:mm:ss"
                textBox_From.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");

                textBox_to.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
            }
            else if (comboBox_DownloadType.SelectedIndex == 1)
            {

                checkBox_ImageRequried.Visible = true;
                textBox_From.Visible = true;
                textBox_to.Visible = true;

                fromlable.Visible = true;
                tolable.Visible = true;
                fromlable.Text = "StartSeq";
                tolable.Text = "EndSeq";

                label_resultInfo.Text = "";

                textBox_nearest.Visible = true;
                Nearesttime.Visible = true;


                textBox_From.Text = "1";
                textBox_to.Text = "100";
                textBox_nearest.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");

            }
            else if (comboBox_DownloadType.SelectedIndex == 2)
            {

                checkBox_ImageRequried.Visible = false;

                fromlable.Visible = false;
                tolable.Visible = false;

                textBox_nearest.Visible = true;
                Nearesttime.Visible = true;


                textBox_From.Visible = false;
                textBox_to.Visible = false;
                textBox_nearest.Visible = false;

                Nearesttime.Visible = false;

            }
        }


        /*public void GetTransactions(int threadNo)
        {
            // get the time based dounload and check the transaction
            for (int i = 0; i < 50; i++)
            {
                Invoke(new MethodInvoker(() =>
                {
                    textBox_ResponceData.AppendText(String.Format("Trying to download transaction for the {0} of {1} in thread {3} {2}", (i + 1), 50, Environment.NewLine, threadNo));
                }));
                //Application.DoEvents();

                if (m_Communicator != null)
                {
                    String status;

                    List<ManagedTransactionDetails> transactions = m_Communicator.GetTransactions(textBox_From.Text.ToString(), textBox_to.Text.ToString(),
                        checkBox_ImageRequried.Checked, 90000, out status);

                    //label_resultInfo.Text = String.Format("Downloaded Transaction Count : {0}", transactions.Count);


                    Invoke(new MethodInvoker(() =>
                    {
                        textBox_ResponceData.AppendText(String.Format("{0} : Downloaded Transaction Count : {1}",
                            DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"), transactions.Count));
                        textBox_ResponceData.AppendText(Environment.NewLine);
                    }));

                    // Application.DoEvents();
                    System.Threading.Thread.Sleep(500);

                    foreach (var t in transactions)
                    {
                        if (t.Image != null)
                        {
                            t.Image.Dispose();
                            t.Image = null;
                        }
                    }

                    Invoke(new MethodInvoker(() =>
                    {
                        lable_Error_Status.Text = "Request Status : " + status;
                        lable_Error_Status.Font = new Font(lable_Error_Status.Font.Name, lable_Error_Status.Font.SizeInPoints, FontStyle.Underline);
                        transactions = null;
                    }));

                    //Application.DoEvents();
                }
            }*/


        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox_DownloadType.SelectedItem.ToString() == "Time")
            {
                Application.DoEvents();

                if (m_Communicator != null)
                {
                    String status;

                    List<ManagedTransactionDetails> transactions = m_Communicator.GetTransactions(textBox_From.Text.ToString(), textBox_to.Text.ToString(),
                        checkBox_ImageRequried.Checked, 90000, out status);

                    textBox_ResponceData.AppendText(String.Format("{0} : Downloaded Transaction Count : {1}",
                        DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"), transactions.Count));
                    textBox_ResponceData.AppendText(Environment.NewLine);

                    Application.DoEvents();

                    foreach (var t in transactions)
                    {
                        if (t.Image != null)
                        {
                            t.Image.Dispose();
                            t.Image = null;
                        }
                    }

                    lable_Error_Status.Text = "Request Status : " + status;
                    lable_Error_Status.Font = new Font(lable_Error_Status.Font.Name, lable_Error_Status.Font.SizeInPoints, FontStyle.Underline);
                    transactions = null;

                    Application.DoEvents();
                }
            }
            else if (comboBox_DownloadType.SelectedItem.ToString() == "Sequence No")
            {
                label_resultInfo.Text = "Downloaded Transaction Count : ";

                if (m_Communicator != null)
                {
                    String status;

                    List<ManagedTransactionDetails> transactions = m_Communicator.GetTransactions(Convert.ToInt32(textBox_From.Text), Convert.ToInt32(textBox_to.Text), textBox_nearest.Text.ToString(), checkBox_ImageRequried.Checked, 90000, out status);

                    textBox_ResponceData.AppendText(String.Format("Downloaded Transaction Count : {0}", transactions.Count));
                    textBox_ResponceData.AppendText(Environment.NewLine);

                    lable_Error_Status.Text = String.Format("Request Status : {0} {1}", status, Environment.NewLine);

                    transactions.Clear();
                    transactions = null;
                }
            }
            else
            {
                if (m_Communicator != null)
                {
                    String status;

                    Dictionary<String, int> statistics = m_Communicator.GetStatistics(30000, out status);

                    int totalVehicle = 0;
                    foreach (KeyValuePair<String, int> v in statistics)
                    {
                        totalVehicle += v.Value;
                    }

                    textBox_ResponceData.AppendText(String.Format(" Vechicle Type : {0} Total Vechicle : {1} {2}", statistics.Count, totalVehicle, Environment.NewLine));

                    lable_Error_Status.Text = String.Format("Request Status : {0} {1}", status, Environment.NewLine);

                }
            }
        }

    }
}
