const express = require('express');
const xml2js = require('xml2js');
const fs = require('fs');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;

// Middleware to parse XML bodies
app.use(bodyParser.text({ type: 'application/xml' }));

// XML Parser configuration
const xmlParser = new xml2js.Parser({ 
    explicitArray: false,  // Prevent creating arrays for single elements
    trim: true,            // Trim whitespace
    explicitRoot: false,   // Don't keep root element
    mergeAttrs: true       // Merge attributes into parent object
});

const saveDirectory = path.join(__dirname, 'received_xmls');

// Create the directory if it doesn't exist
if (!fs.existsSync(saveDirectory)) {
    fs.mkdirSync(saveDirectory);
}

// Function to save received data as a file
function saveReceivedDataAsFile(xmlData) {
    return new Promise((resolve, reject) => {
        const fileName = `response_${Date.now()}.xml`;
        const filePath = path.join(saveDirectory, fileName);

        fs.writeFile(filePath, xmlData, 'utf8', (err) => {
            if (err) {
                reject(err);
                return;
            }
            resolve(filePath);
        });
    });
}


// Function to ensure array
function ensureArray(item) {
    return Array.isArray(item) ? item : (item ? [item] : []);
}

// Safe property access helper
function safeGet(obj, path, defaultValue = undefined) {
    return path.split('.').reduce((acc, part) => 
        acc && acc[part] !== undefined ? acc[part] : defaultValue, obj);
}

// Function to parse plaza details XML
function parsePlazaDetails(xmlData) {
    return new Promise((resolve, reject) => {
        xmlParser.parseString(xmlData, (err, result) => {
            if (err) {
                reject(err);
                return;
            }

            // Safely extract head information
            const head = result.Head || {};

            // Safely extract plaza information
            const plaza = result.PLaza || {};

            // Transform the parsed XML into a more structured format
            const plazaDetails = {
                messageId: head.msgId || '',
                orgId: head.orgId || '',
                timestamp: head.ts || '',
                version: head.ver || '',
                plaza: {
                    id: plaza.id || '',
                    name: plaza.name || '',
                    geoCode: plaza.geoCode || '',
                    type: plaza.type || '',
                    subtype: plaza.subtype || ''
                },
                laneDetails: plaza.LaneDetails 
                    ? ensureArray(plaza.LaneDetails.Lane).map(lane => ({
                        id: lane.id || '',
                        direction: ensureArray(lane.Detail).find(d => d.name === 'Direction')?.value || '',
                        readerID: ensureArray(lane.Detail).find(d => d.name === 'ReaderID')?.value || '',
                        laneStatus: ensureArray(lane.Detail).find(d => d.name === 'LaneStatus')?.value || '',
                        mode: ensureArray(lane.Detail).find(d => d.name === 'Mode')?.value || '',
                        laneType: ensureArray(lane.Detail).find(d => d.type === 'LaneType')?.value || ''
                    }))
                    : [],
                vehicleClasses: plaza.PlazaVehicleClass 
                    ? ensureArray(plaza.PlazaVehicleClass.VehicleClass).map(vc => ({
                        id: vc.id || '',
                        name: vc.name || '',
                        description: vc.Detail?.name === 'Description' ? vc.Detail.value : null
                    }))
                    : [],
                tollFareRules: plaza.TollFareRules && plaza.TollFareRules.FareType
                    ? ensureArray(plaza.TollFareRules.FareType).map(fareType => ({
                        id: fareType.id || '',
                        name: fareType.name || '',
                        vehicleClasses: fareType.VehicleClass 
                            ? ensureArray(fareType.VehicleClass).map(vc => ({
                                id: vc.id || '',
                                name: vc.name || '',
                                commercialVehicle: ensureArray(vc.Detail).find(d => d.name === 'COMVEHICLE')?.value || '',
                                amount: ensureArray(vc.Detail).find(d => d.name === 'amount')?.value || '',
                                currency: ensureArray(vc.Detail).find(d => d.name === 'Currency')?.value || ''
                            }))
                            : []
                    }))
                    : [],
                passSchemes: plaza.PassSchemes && plaza.PassSchemes.Pass
                    ? ensureArray(plaza.PassSchemes.Pass).map(pass => ({
                        id: pass.id || '',
                        name: pass.name || '',
                        vehicleClassId: ensureArray(pass.Detail).find(d => d.name === 'VehicleClassId')?.value || '',
                        passType: ensureArray(pass.Detail).find(d => d.name === 'PassType')?.value || '',
                        allowedTrips: ensureArray(pass.Detail).find(d => d.name === 'ALLOWEDTRIPS')?.value || '',
                        entryPlazaId: ensureArray(pass.Detail).find(d => d.name === 'ENTRYPLAZAID')?.value || '',
                        exitPlazaId: ensureArray(pass.Detail).find(d => d.name === 'EXITPLAZAID')?.value || '',
                        description: ensureArray(pass.Detail).find(d => d.name === 'Description')?.value || '',
                        amount: ensureArray(pass.Detail).find(d => d.name === 'Amount')?.value || '',
                        currency: ensureArray(pass.Detail).find(d => d.name === 'Currency')?.value || ''
                    }))
                    : []
            };

            resolve(plazaDetails);
        });
    });
}

// Endpoint to handle plaza details XML
app.post('/plaza-details', async (req, res) => {
    try {
        const xmlData = req.body;
        const parsedDetails = await parsePlazaDetails(xmlData);
        const filePath = await saveReceivedDataAsFile(xmlData);
        console.log(`Data saved to: ${filePath}`);
        res.json({
            status: 'success',
            data: parsedDetails
        });
    } catch (error) {
        console.error('XML Parsing Error:', error);
        res.status(400).json({
            status: 'error',
            message: 'Invalid XML format',
            error: error.message
        });
    }
});

// Debugging endpoint to see raw parsed result
app.post('/debug-xml', async (req, res) => {
    try {
        const xmlData = req.body;
        xmlParser.parseString(xmlData, (err, result) => {
            if (err) {
                res.status(400).json({
                    status: 'error',
                    message: 'Parsing error',
                    error: err.message
                });
                return;
            }
            res.json({
                status: 'success',
                rawResult: result
            });
        });
    } catch (error) {
        res.status(500).json({
            status: 'error',
            message: 'Unexpected error',
            error: error.message
        });
    }
});

function parseResponsePay(xmlData) {
    return new Promise((resolve, reject) => {
        xmlParser.parseString(xmlData, (err, result) => {
            if (err) {
                reject(err);
                return;
            }

            // Safely extract head information
            const head = result.Head || {};

            // Safely extract transaction information
            const txn = result.Txn || {};
            const entryTxn = txn.EntryTxn || {};

            // Safely extract response information
            const resp = result.Resp || {};
            const vehicleDetails = resp.Vehicle?.VehicleDetails || {};

            // Transform the parsed XML into a more structured format
            const responsePayDetails = {
                // Head Information
                messageId: head.msgId || '',
                organizationId: head.orgId || '',
                timestamp: head.ts || '',
                version: head.ver || '',

                // Transaction Details
                transaction: {
                    id: txn.id || '',
                    note: txn.note || '',
                    originTransactionId: txn.orgTxnId || '',
                    referenceId: txn.refId || '',
                    referenceUrl: txn.refUrl || '',
                    transactionTimestamp: txn.ts || '',
                    transactionType: txn.type || '',
                    transactionLiability: txn.txnLiability || '',

                    // Entry Transaction Details
                    entryTransaction: {
                        id: entryTxn.id || '',
                        timestampRead: entryTxn.tsRead || '',
                        timestamp: entryTxn.ts || '',
                        type: entryTxn.type || ''
                    }
                },

                // Response Details
                response: {
                    plazaId: resp.plazaId || '',
                    responseCode: resp.respCode || '',
                    result: resp.result || '',
                    timestamp: resp.ts || '',
                    fareType: resp.FareType || '',

                    // Reference Details
                    reference: {
                        tollFare: resp.Ref?.TollFare || '',
                        approvalNumber: resp.Ref?.approvalNum || '',
                        errorCode: resp.Ref?.errCode || '',
                        settlementCurrency: resp.Ref?.settCurrency || ''
                    },

                    // Vehicle Details
                    vehicle: {
                        transactionId: resp.Vehicle?.TID || '',
                        tagId: resp.Vehicle?.tagId || '',
                        details: ensureArray(resp.Vehicle?.VehicleDetails?.Detail).reduce((acc, detail) => {
                            if (detail.name && detail.value) {
                                acc[detail.name] = detail.value;
                            }
                            return acc;
                        }, {})
                    }
                }
            };

            resolve(responsePayDetails);
        });
    });
}

// Endpoint to handle response pay XML
app.post('/response-pay', async (req, res) => {
    try {
        const xmlData = req.body;
        const parsedDetails = await parseResponsePay(xmlData);
        const filePath = await saveReceivedDataAsFile(xmlData);
        console.log(`Data saved to: ${filePath}`);
        
        res.json({
            status: 'success',
            data: parsedDetails
        });
    } catch (error) {
        console.error('XML Parsing Error:', error);
        res.status(400).json({
            status: 'error',
            message: 'Invalid XML format',
            error: error.message
        });
    }
});

// Debugging endpoint to see raw parsed result
app.post('/debug-xml', async (req, res) => {
    try {
        const xmlData = req.body;
        xmlParser.parseString(xmlData, (err, result) => {
            if (err) {
                res.status(400).json({
                    status: 'error',
                    message: 'Parsing error',
                    error: err.message
                });
                return;
            }
            res.json({
                status: 'success',
                rawResult: result
            });
        });
    } catch (error) {
        res.status(500).json({
            status: 'error',
            message: 'Unexpected error',
            error: error.message
        });
    }
});

function parseResponseTagDetails(xmlData) {
    return new Promise((resolve, reject) => {
        xmlParser.parseString(xmlData, (err, result) => {
            if (err) {
                reject(err);
                return;
            }

            // Safely extract head information
            const head = result.Head || {};

            // Safely extract transaction information
            const txn = result.Txn || {};
            const resp = txn.Resp || {};
            const vehicle = resp.Vehicle || {};
            const vehicleDetails = vehicle.VehicleDetails || [];

            // Transform the parsed XML into a structured format
            const responseTagDetails = {
                // Head Information
                messageId: head.msgId || '',
                organizationId: head.orgId || '',
                timestamp: head.ts || '',
                version: head.ver || '',

                // Transaction Details
                transaction: {
                    id: txn.id || '',
                    note: txn.note || '',
                    originTransactionId: txn.orgTxnId || '',
                    referenceId: txn.refId || '',
                    referenceUrl: txn.refUrl || '',
                    transactionTimestamp: txn.ts || '',
                    transactionType: txn.type || '',
                },

                // Response Details
                response: {
                    responseCode: resp.respCode || '',
                    result: resp.result || '',
                    successRequestCount: resp.successReqCnt || 0,
                    totalRequestCount: resp.totReqCnt || 0,
                    timestamp: resp.ts || '',

                    // Vehicle Details
                    vehicles: ensureArray(vehicleDetails).map(detail => {
                        const vehicleInfo = {};
                        ensureArray(detail.Detail).forEach(d => {
                            if (d.name && d.value) {
                                vehicleInfo[d.name] = d.value;
                            }
                        });
                        return vehicleInfo;
                    })
                }
            };

            resolve(responseTagDetails);
        });
    });
}

// Endpoint to handle response tag details XML
app.post('/response-tag-details', async (req, res) => {
    try {
        const xmlData = req.body;
        const parsedDetails = await parseResponseTagDetails(xmlData);
        const filePath = await saveReceivedDataAsFile(xmlData);
        console.log(`Data saved to: ${filePath}`);

        res.json({
            status: 'success',
            data: parsedDetails
        });
    } catch (error) {
        console.error('XML Parsing Error:', error);
        res.status(400).json({
            status: 'error',
            message: 'Invalid XML format',
            error: error.message
        });
    }
});

// Debugging endpoint to see raw parsed result
app.post('/debug-xml', async (req, res) => {
    try {
        const xmlData = req.body;
        xmlParser.parseString(xmlData, (err, result) => {
            if (err) {
                res.status(400).json({
                    status: 'error',
                    message: 'Parsing error',
                    error: err.message
                });
                return;
            }
            res.json({
                status: 'success',
                rawResult: result
            });
        });
    } catch (error) {
        res.status(500).json({
            status: 'error',
            message: 'Unexpected error',
            error: error.message
        });
    }
});

function parseSyncTimeResponse(xmlData) {
    return new Promise((resolve, reject) => {
        xmlParser.parseString(xmlData, (err, result) => {
            if (err) {
                reject(err);
                return;
            }

            // Safely extract head information
            const head = result.Head || {};

            // Safely extract response information
            const resp = result.Resp || {};

            // Transform the parsed XML into a more structured format
            const syncTimeDetails = {
                // Head Information
                messageId: head.msgId || '',
                organizationId: head.orgId || '',
                timestamp: head.ts || '',
                version: head.ver || '',

                // Response Details
                response: {
                    responseCode: resp.respCode || '',
                    result: resp.result || '',
                    timestamp: resp.ts || '',

                    // Server Time Details
                    serverTime: resp.Time?.serverTime || ''
                }
            };

            resolve(syncTimeDetails);
        });
    });
}

// Endpoint to handle SyncTime Response XML
app.post('/sync-time-response', async (req, res) => {
    try {
        const xmlData = req.body;
        const parsedDetails = await parseSyncTimeResponse(xmlData);
        const filePath = await saveReceivedDataAsFile(xmlData);
        console.log(`Data saved to: ${filePath}`);
        
        res.json({
            status: 'success',
            data: parsedDetails
        });
    } catch (error) {
        console.error('XML Parsing Error:', error);
        res.status(400).json({
            status: 'error',
            message: 'Invalid XML format',
            error: error.message
        });
    }
});

// Debugging endpoint to see raw parsed result
app.post('/debug-sync-time-xml', async (req, res) => {
    try {
        const xmlData = req.body;
        xmlParser.parseString(xmlData, (err, result) => {
            if (err) {
                res.status(400).json({
                    status: 'error',
                    message: 'Parsing error',
                    error: err.message
                });
                return;
            }
            res.json({
                status: 'success',
                rawResult: result
            });
        });
    } catch (error) {
        res.status(500).json({
            status: 'error',
            message: 'Unexpected error',
            error: error.message
        });
    }
});

function parseTollplazaHeartbeatResponse(xmlData) {
    return new Promise((resolve, reject) => {
        xmlParser.parseString(xmlData, (err, result) => {
            if (err) {
                reject(err);
                return;
            }

            // Extract head and transaction details
            const head = result.Head || {};
            const txn = result.Txn || {};
            const resp = txn.Resp || {};

            // Return structured response
            const heartbeatDetails = {
                // Head Information
                version: head.ver || '',
                timestamp: head.ts || '',
                organizationId: head.orgId || '',
                messageId: head.msgId || '',

                // Transaction Information
                transaction: {
                    transactionId: txn.id || '',
                    referenceId: txn.refId || '',
                    referenceUrl: txn.refUrl || '',
                    transactionTimestamp: txn.ts || '',
                    type: txn.type || '',
                    originalTransactionId: txn.orgTxnId || '',

                    // Response Details
                    response: {
                        errorCode: resp.errCode || '',
                        result: resp.result || '',
                        responseTimestamp: resp.ts || ''
                    }
                }
            };

            resolve(heartbeatDetails);
        });
    });
}

// Endpoint to handle Tollplaza Heartbeat Response
app.post('/tollPlaza-heartbeat-response', async (req, res) => {
    try {
        const xmlData = req.body;
        const parsedDetails = await parseTollplazaHeartbeatResponse(xmlData);
        const filePath = await saveReceivedDataAsFile(xmlData);
        console.log(`Data saved to: ${filePath}`);
        
        res.json({
            status: 'success',
            data: parsedDetails
        });
    } catch (error) {
        console.error('XML Parsing Error:', error);
        res.status(400).json({
            status: 'error',
            message: 'Invalid XML format',
            error: error.message
        });
    }
});

// Debugging endpoint to see raw parsed result
app.post('/debug-tollplaza-heartbeat-xml', async (req, res) => {
    try {
        const xmlData = req.body;
        xmlParser.parseString(xmlData, (err, result) => {
            if (err) {
                res.status(400).json({
                    status: 'error',
                    message: 'Parsing error',
                    error: err.message
                });
                return;
            }
            res.json({
                status: 'success',
                rawResult: result
            });
        });
    } catch (error) {
        res.status(500).json({
            status: 'error',
            message: 'Unexpected error',
            error: error.message
        });
    }
});

function parseTransactionStatusResponse(xmlData) {
    return new Promise((resolve, reject) => {
        xmlParser.parseString(xmlData, (err, result) => {
            if (err) {
                reject(err);
                return;
            }

            // Extract head and transaction details
            const head = result.Head || {};
            const txn = result.Txn || {};
            const resp = txn.Resp || {};

            // Parse transaction status list if present
            const statusList = txn.TxnStatusReqList?.Status || [];
            const txnStatusList = statusList.map(status => ({
                txnId: status.txnId || '',
                txnDate: status.txnDate || '',
                plazaId: status.plazaId || '',
                laneId: status.laneId || '',
                result: status.result || '',
                errCode: status.errCode || '',
                settleDate: status.settleDate || '',
                txnList: (status.TxnList || []).map(txnDetail => ({
                    txnStatus: txnDetail.txnStatus || '',
                    txnReaderTime: txnDetail.txnReaderTime || '',
                    txnType: txnDetail.txnType || '',
                    txnReceivedTime: txnDetail.txnReceivedTime || '',
                    tollFare: txnDetail.TollFare || '',
                    fareType: txnDetail.FareType || '',
                    vehicleClass: txnDetail.VehicleClass || '',
                    regNumber: txnDetail.RegNumber || '',
                    errCode: txnDetail.errCode || ''
                }))
            }));

            // Return structured response
            const transactionDetails = {
                version: head.ver || '',
                timestamp: head.ts || '',
                organizationId: head.orgId || '',
                messageId: head.msgId || '',

                transaction: {
                    transactionId: txn.id || '',
                    referenceId: txn.refId || '',
                    referenceUrl: txn.refUrl || '',
                    transactionTimestamp: txn.ts || '',
                    type: txn.type || '',
                    originalTransactionId: txn.orgTxnId || '',

                    response: {
                        responseTimestamp: resp.ts || '',
                        result: resp.result || '',
                        responseCode: resp.respCode || '',
                        totalRequestCount: resp.totReqCnt || '',
                        successRequestCount: resp.sucessReqCnt || ''
                    },
                    txnStatusReqList: txnStatusList
                }
            };

            resolve(transactionDetails);
        });
    });
}

// Endpoint to handle Check Transaction Status Response
app.post('/check-transaction-status', async (req, res) => {
    try {
        const xmlData = req.body;
        const parsedDetails = await parseTransactionStatusResponse(xmlData);
        const filePath = await saveReceivedDataAsFile(xmlData);
        console.log(`Data saved to: ${filePath}`);
        
        res.json({
            status: 'success',
            data: parsedDetails
        });
    } catch (error) {
        console.error('XML Parsing Error:', error);
        res.status(400).json({
            status: 'error',
            message: 'Invalid XML format',
            error: error.message
        });
    }
});

function parseExceptionResponse(xmlData) {
    return new Promise((resolve, reject) => {
        xmlParser.parseString(xmlData, (err, result) => {
            if (err) {
                reject(err);
                return;
            }

            // Extract head and transaction details
            const head = result.Head || {};
            const txn = result.Txn || {};
            const resp = txn.Resp || {};
            const exception = resp.Exception || {};

            // Extract tag details
            const tags = (exception.Tag || []).map(tag => ({
                tagId: tag.tagId || ''
            }));

            // Return structured response
            const exceptionDetails = {
                version: head.ver || '',
                timestamp: head.ts || '',
                organizationId: head.orgId || '',
                messageId: head.msgId || '',

                transaction: {
                    transactionId: txn.id || '',
                    referenceId: txn.refId || '',
                    referenceUrl: txn.refUrl || '',
                    transactionTimestamp: txn.ts || '',
                    type: txn.type || '',
                    originalTransactionId: txn.orgTxnId || '',

                    response: {
                        responseTimestamp: resp.ts || '',
                        responseCode: resp.respCode || '',
                        result: resp.result || '',
                        successRequestCount: resp.successReqCnt || '',
                        totalRequestCount: resp.totReqCnt || '',
                        totalMessages: resp.totalMsg || '',
                        totalTagsInMessage: resp.totalTagsInMsg || '',
                        totalTagsInResponse: resp.totalTagsInResponse || ''
                    },
                    exception: {
                        description: exception.desc || '',
                        errorCode: exception.errCode || '',
                        exceptionCode: exception.excCode || '',
                        lastUpdatedTime: exception.lastupdatedTime || '',
                        priority: exception.priority || '',
                        result: exception.result || '',
                        totalTagCount: exception.totalTag || '',
                        tags: tags
                    }
                }
            };

            resolve(exceptionDetails);
        });
    });
}

// Endpoint to handle Get Exception Response
app.post('/get-exception-list', async (req, res) => {
    try {
        const xmlData = req.body;
        const parsedDetails = await parseExceptionResponse(xmlData);
        const filePath = await saveReceivedDataAsFile(xmlData);
        console.log(`Data saved to: ${filePath}`);
        
        res.json({
            status: 'success',
            data: parsedDetails
        });
    } catch (error) {
        console.error('XML Parsing Error:', error);
        res.status(400).json({
            status: 'error',
            message: 'Invalid XML format',
            error: error.message
        });
    }
});

function parseQueryExceptionResponse(xmlData) {
    return new Promise((resolve, reject) => {
        xmlParser.parseString(xmlData, (err, result) => {
            if (err) {
                reject(err);
                return;
            }

            // Extract head and transaction details
            const head = result.Head || {};
            const txn = result.Txn || {};
            const resp = txn.Resp || {};
            const exception = resp.Exception || {};

            // Extract tag details
            const tags = (exception.Tag || []).map(tag => ({
                tagId: tag.tagId || '',
                operation: tag.op || '',
                updatedTime: tag.updatedTime || ''
            }));

            // Return structured response
            const exceptionDetails = {
                version: head.ver || '',
                timestamp: head.ts || '',
                organizationId: head.orgId || '',
                messageId: head.msgId || '',

                transaction: {
                    transactionId: txn.id || '',
                    referenceId: txn.refId || '',
                    referenceUrl: txn.refUrl || '',
                    transactionTimestamp: txn.ts || '',
                    type: txn.type || '',
                    originalTransactionId: txn.orgTxnId || '',

                    response: {
                        responseTimestamp: resp.ts || '',
                        responseCode: resp.respCode || '',
                        result: resp.result || '',
                        successRequestCount: resp.successReqCnt || '',
                        totalRequestCount: resp.totReqCnt || '',
                        totalMessages: resp.totalMsg || '',
                        totalTagsInMessage: resp.totalTagsInMsg || '',
                        totalTagsInResponse: resp.totalTagsInResponse || ''
                    },
                    exception: {
                        description: exception.desc || '',
                        errorCode: exception.errCode || '',
                        exceptionCode: exception.excCode || '',
                        priority: exception.priority || '',
                        result: exception.result || '',
                        totalTagCount: exception.totalTag || '',
                        tags: tags
                    }
                }
            };

            resolve(exceptionDetails);
        });
    });
}

// Endpoint to handle Response Query Exception List
app.post('/query-exception-list-response', async (req, res) => {
    try {
        const xmlData = req.body;
        const parsedDetails = await parseQueryExceptionResponse(xmlData);
        const filePath = await saveReceivedDataAsFile(xmlData);
        console.log(`Data saved to: ${filePath}`);
        
        res.json({
            status: 'success',
            data: parsedDetails
        });
    } catch (error) {
        console.error('XML Parsing Error:', error);
        res.status(400).json({
            status: 'error',
            message: 'Invalid XML format',
            error: error.message
        });
    }
});

function parseSetPassSchemeResponse(xmlData) {
    return new Promise((resolve, reject) => {
        xmlParser.parseString(xmlData, (err, result) => {
            if (err) {
                reject(err);
                return;
            }

            // Extract head, transaction, command, and result details
            const head = result.Head || {};
            const txn = result.Txn || {};
            const command = result.Command || {};
            const resultElement = result.Result || {};
            const destination = result.Destination || {};
            const source = result.Source || {};

            // Extract parameter details
            const params = (command.Param || []).map(param => ({
                name: param.name || '',
                type: param.type || '',
                value: param.value || '',
                length: param.length || ''
            }));

            // Extract object list details
            const objectList = (command.ObjectList || {}).Object || [];
            const schemes = objectList.map(object => ({
                schemeName: object.name || '',
                items: (object.Item || []).map(item => ({
                    itemName: item.name || '',
                    itemType: item.type || '',
                    itemValue: item.value || ''
                }))
            }));

            // Construct the parsed response
            const responseDetails = {
                version: head.ver || '',
                timestamp: head.ts || '',
                organizationId: head.orgId || '',
                messageId: head.msgId || '',

                transaction: {
                    transactionId: txn.id || '',
                    transactionTimestamp: txn.ts || '',
                    type: txn.type || '',
                    originalTransactionId: txn.orgTxnId || '',

                    command: {
                        commandName: command.name || '',
                        commandType: command.type || '',
                        numParams: command.NumParams || '',
                        params: params
                    },

                    result: {
                        resultTimestamp: resultElement.ts || '',
                        resultStatus: resultElement.status || '',
                        resultCode: resultElement.code || ''
                    },

                    destination: {
                        address: destination.addr || '',
                        name: destination.name || '',
                        type: destination.type || ''
                    },

                    source: {
                        address: source.addr || '',
                        name: source.name || '',
                        type: source.type || ''
                    },

                    schemes: schemes
                }
            };

            resolve(responseDetails);
        });
    });
}

// Endpoint to handle Set Pass Scheme Response
app.post('/set-pass-scheme-response', async (req, res) => {
    try {
        const xmlData = req.body;
        const parsedDetails = await parseSetPassSchemeResponse(xmlData);
        const filePath = await saveReceivedDataAsFile(xmlData);
        console.log(`Data saved to: ${filePath}`);

        res.json({
            status: 'success',
            data: parsedDetails
        });
    } catch (error) {
        console.error('XML Parsing Error:', error);
        res.status(400).json({
            status: 'error',
            message: 'Invalid XML format',
            error: error.message
        });
    }
});

function parseParticipantsListResponse(xmlData) {
    return new Promise((resolve, reject) => {
        xmlParser.parseString(xmlData, (err, result) => {
            if (err) {
                reject(err);
                return;
            }

            // Extract head, transaction, and response details
            const head = result.Head || {};
            const txn = result.Txn || {};
            const resp = txn.Resp || {};
            const participantList = resp.ParticipantList || [];

            // Extract participant details
            const participants = (participantList.Participant || []).map(participant => ({
                name: participant.name || '',
                errCode: participant.errCode || '',
                issuerIin: participant.issuerIin || ''
            }));

            // Return structured response
            const responseDetails = {
                version: head.ver || '',
                timestamp: head.ts || '',
                organizationId: head.orgId || '',
                messageId: head.msgId || '',

                transaction: {
                    transactionId: txn.id || '',
                    referenceId: txn.refId || '',
                    referenceUrl: txn.refUrl || '',
                    transactionTimestamp: txn.ts || '',
                    type: txn.type || '',
                    originalTransactionId: txn.orgTxnId || '',

                    response: {
                        responseTimestamp: resp.ts || '',
                        result: resp.result || '',
                        responseCode: resp.respCode || '',
                        numberOfParticipants: resp.NoOfParticipant || '',
                        participants: participants
                    }
                }
            };

            resolve(responseDetails);
        });
    });
}

// Endpoint to handle Participants List Response
app.post('/participants-list-response', async (req, res) => {
    try {
        const xmlData = req.body;
       
        const parsedDetails = await parseParticipantsListResponse(xmlData);
        const filePath = await saveReceivedDataAsFile(xmlData);
        console.log(`Data saved to: ${filePath}`);
        
        res.json({
            status: 'success',
            data: parsedDetails
        });
    } catch (error) {
        console.error('XML Parsing Error:', error);
        res.status(400).json({
            status: 'error',
            message: 'Invalid XML format',
            error: error.message
        });
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Plaza Details API listening at http://localhost:${port}`);
});

module.exports = app;